/* Петля: клиентский слой. Даёт странице те же методы базы, что были раньше (db, user, assets),
   но работает через свой сервер: /api/db, /api/auth, /api/assets. Права проверяет сервер. */
(function(){
  'use strict';
  async function J(url, opt){
    const o=Object.assign({credentials:'same-origin'}, opt||{});
    if(typeof o.body==='string'){ o.headers=Object.assign({'content-type':'application/json'}, o.headers||{}); }
    const r=await fetch(url,o);
    const j=await r.json().catch(()=>({}));
    if(!r.ok){ const e=new Error(j.error||('Ошибка '+r.status)); e.code=j.code||'error'; e.status=r.status; throw e; }
    return j;
  }
  const meP=J('/api/me').catch(()=>({uid:null,isOwner:false}));

  /* live updates: server pushes "changed", every subscription re-reads its query */
  const subs=new Set(); let es=null, timer=null;
  function fire(){ clearTimeout(timer); timer=setTimeout(()=>subs.forEach(f=>{ try{ f(); }catch(e){} }),120); }
  function ensureEvents(){ if(es||!window.EventSource) return; es=new EventSource('/api/events'); es.onmessage=fire; }

  function cmp(x,op,v){
    switch(op){
      case '==': case '===': return x===v;
      case '!=': case '!==': return x!==v;
      case '<': return x<v; case '<=': return x<=v;
      case '>': return x>v; case '>=': return x>=v;
      default: return false;
    }
  }
  function snapOfDocs(docs){
    return { docs: docs.map(d=>({ id:d.id, exists:true, data:()=>d.data, ref:null })), empty: !docs.length, size: docs.length };
  }
  function makeColl(path, q){
    q=q||{f:[],o:null,l:null};
    const api={
      where(field,op,val){ return makeColl(path,{f:q.f.concat([[field,op,val]]),o:q.o,l:q.l}); },
      orderBy(field,dir){ return makeColl(path,{f:q.f,o:[field,dir||'asc'],l:q.l}); },
      limit(n){ return makeColl(path,{f:q.f,o:q.o,l:n}); },
      async get(){
        const r=await J('/api/db?path='+encodeURIComponent(path));
        let docs=(r.docs||[]).filter(d=>q.f.every(([k,op,v])=>cmp(d.data[k],op,v)));
        if(q.o){ const [k,dir]=q.o; docs.sort((a,b)=>{ const x=a.data[k], y=b.data[k]; const c=x>y?1:x<y?-1:0; return dir==='desc'?-c:c; }); }
        if(q.l!=null) docs=docs.slice(0,q.l);
        return snapOfDocs(docs);
      },
      onSnapshot(cb,err){
        let alive=true;
        const run=()=>{ api.get().then(s=>{ if(alive) cb(s); }).catch(e=>{ if(alive&&err) err(e); }); };
        subs.add(run); ensureEvents(); run();
        return ()=>{ alive=false; subs.delete(run); };
      },
      async add(data){
        const r=await J('/api/db/write',{method:'POST',body:JSON.stringify({writes:[{op:'add',path,data}]})});
        return { id: r.ids[0] };
      },
    };
    return api;
  }
  function makeDoc(path){
    const write=(op,data)=>J('/api/db/write',{method:'POST',body:JSON.stringify({writes:[{op,path,data}]})});
    const d={
      async get(){
        const r=await J('/api/db?path='+encodeURIComponent(path));
        return { exists: !!r.exists, id: path.split('/').pop(), data: ()=> r.exists ? r.data : undefined };
      },
      set(data){ return write('set',data); },
      update(data){ return write('update',data); },
      delete(){ return write('delete'); },
      onSnapshot(cb,err){
        let alive=true;
        const run=()=>{ d.get().then(s=>{ if(alive) cb(s); }).catch(e=>{ if(alive&&err) err(e); }); };
        subs.add(run); ensureEvents(); run();
        return ()=>{ alive=false; subs.delete(run); };
      },
    };
    return d;
  }
  const db={ collection: makeColl, doc: makeDoc };

  const user={
    async id(){ return (await meP).uid||null; },
    async me(){ return null; },
    async can(name){ const m=await meP; return name==='data.write' ? !!m.uid : false; },
    async isOwner(){ return !!(await meP).isOwner; },
    async profiles(){ return {}; },
  };

  const assets={
    async upload(blob,opt){
      const type=(opt&&opt.type)||blob.type||'application/octet-stream';
      const r=await fetch('/api/assets',{method:'POST',credentials:'same-origin',headers:{'content-type':type},body:blob});
      const j=await r.json().catch(()=>({}));
      if(!r.ok){ const e=new Error(j.error||'Не удалось загрузить'); e.code=j.code||'error'; throw e; }
      return j;
    },
    async delete(id){ await J('/api/assets/'+encodeURIComponent(id),{method:'DELETE'}); },
  };

  const ready={db,user,assets};
  window.claude={ use: async (name)=>{ await meP; return ready[name]||null; } };
  window.petlyaApi={ post: (u,b)=>J(u,{method:'POST',body:JSON.stringify(b||{})}) };
})();
