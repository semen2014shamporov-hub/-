// «Петля» — сервер без внешних зависимостей (только встроенные модули Node.js 18+).
// Хранит данные в одном JSON-файле в DATA_DIR, видео — в DATA_DIR/assets.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(__dirname, 'data'));
const OWNER_EMAIL = (process.env.OWNER_EMAIL || '').trim().toLowerCase();
const SECURE_COOKIE = process.env.COOKIE_SECURE === '1';
const PUBLIC_DIR = path.join(__dirname, 'public');
const SEED_VIDEO = path.join(__dirname, 'seed', 'promo.mp4');
const MAX_UPLOAD = 20 * 1024 * 1024;
const SESSION_TTL = 30 * 24 * 3600 * 1000;
const COLLECTIONS = new Set(['profiles', 'clips', 'likes', 'comments', 'follows', 'verified', 'config']);
const PROMO_ID = 'promo_petlya_01';
const PROMO_ASSET = 'promo-petlya-01';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const HANDLE_RE = /^[a-z0-9_]{3,20}$/;
const HEX_RE = /^#[0-9a-fA-F]{6}$/;
const SAFE_SEG = /^[A-Za-z0-9_\-.~:@+]{1,200}$/;

fs.mkdirSync(path.join(DATA_DIR, 'assets'), { recursive: true });
const DB_FILE = path.join(DATA_DIR, 'state.json');

/* ---------- состояние и сохранение ---------- */
function load() {
  try {
    const s = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    return { docs: s.docs || {}, users: s.users || {}, emails: s.emails || {}, handles: s.handles || {}, sessions: s.sessions || {}, assets: s.assets || {} };
  } catch (e) {
    return { docs: {}, users: {}, emails: {}, handles: {}, sessions: {}, assets: {} };
  }
}
const state = load();

function flush() {
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(state));
  fs.renameSync(tmp, DB_FILE);
}
let saveT = null;
const sseClients = new Set();
let notifyT = null;
function changed() {
  clearTimeout(saveT);
  saveT = setTimeout(flush, 80);
  clearTimeout(notifyT);
  notifyT = setTimeout(() => { for (const r of sseClients) r.write('data: changed\n\n'); }, 60);
}
for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => { try { flush(); } finally { process.exit(0); } });

const rid = () => crypto.randomBytes(16).toString('base64url');
const norm = (s, max) => String(s ?? '').trim().slice(0, max);
const numOrNull = (v) => (typeof v === 'number' && isFinite(v) ? v : null);
const cleanEmail = (e) => { const x = norm(e, 120).toLowerCase(); return EMAIL_RE.test(x) ? x : null; };

function putDoc(p, data) {
  const prev = state.docs[p];
  state.docs[p] = { data, version: (prev ? prev.version : 0) + 1, t: Date.now() };
}

/* ---------- пароли ---------- */
const SCRYPT = { N: 16384, r: 8, p: 1 };
function hashPassword(pw, salt) { return crypto.scryptSync(pw, salt, 64, SCRYPT).toString('hex'); }
function checkPassword(pw, salt, hash) {
  const a = Buffer.from(hashPassword(pw, salt), 'hex');
  const b = Buffer.from(hash, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
const DUMMY_SALT = crypto.randomBytes(16).toString('hex');
const DUMMY_HASH = hashPassword('dummy-password', DUMMY_SALT);

/* ---------- ограничение попыток входа ---------- */
const attempts = new Map();
function tooMany(req) {
  const ip = String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
  const now = Date.now();
  let a = attempts.get(ip);
  if (!a || a.reset < now) a = { n: 0, reset: now + 15 * 60 * 1000 };
  a.n += 1;
  attempts.set(ip, a);
  return a.n > 30;
}

/* ---------- сессии ---------- */
function sessionOf(req) {
  const m = /(?:^|;\s*)petlya_sid=([0-9a-f]{64})/.exec(req.headers.cookie || '');
  if (!m) return null;
  const s = state.sessions[m[1]];
  if (!s || s.exp < Date.now()) return null;
  const u = state.users[s.uid];
  if (!u) return null;
  return { uid: s.uid, token: m[1], email: u.email, isOwner: !!OWNER_EMAIL && u.email === OWNER_EMAIL };
}
function cookieFlags(req) { return SECURE_COOKIE || req.headers['x-forwarded-proto'] === 'https' ? '; Secure' : ''; }
function startSession(req, res, uid) {
  const now = Date.now();
  for (const [k, v] of Object.entries(state.sessions)) if (v.exp < now) delete state.sessions[k];
  const token = crypto.randomBytes(32).toString('hex');
  state.sessions[token] = { uid, exp: now + SESSION_TTL };
  res.setHeader('Set-Cookie', `petlya_sid=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${SESSION_TTL / 1000}${cookieFlags(req)}`);
  changed();
}

/* ---------- правила доступа (повторяют правила прежней версии) ---------- */
const fail = (code, msg) => ({ ok: false, code, msg });
const deny = () => fail('permission-denied', 'Нет прав на это действие');

function validPath(p) {
  const seg = p.split('/');
  return seg.length >= 2 && seg.length % 2 === 0 && COLLECTIONS.has(seg[0]) && seg.every((s) => SAFE_SEG.test(s));
}

function authorize(op, p, data, sess, existing) {
  const seg = p.split('/');
  const top = seg[0];
  const uid = sess && sess.uid;
  const owner = !!(sess && sess.isOwner);
  data = data || {};

  if (top === 'profiles') {
    if (seg.length !== 2 || seg[1] !== uid || !existing || op !== 'update') return deny();
    const next = { ...existing.data };
    if (data.name !== undefined) { const n = norm(data.name, 30); if (!n) return fail('invalid', 'Введите отображаемое имя'); next.name = n; }
    if (data.bio !== undefined) next.bio = norm(data.bio, 80);
    if (data.color !== undefined) { if (!HEX_RE.test(data.color)) return fail('invalid', 'Неверный цвет'); next.color = data.color; }
    return { ok: true, data: next };
  }

  if (top === 'verified') {
    if (!owner || seg.length !== 2) return fail('permission-denied', 'Галочки выдаёт только владелец');
    if (op === 'delete') return { ok: true };
    if (op !== 'set') return deny();
    return { ok: true, data: { handle: norm(data.handle, 20), t: Date.now() } };
  }

  if (top === 'config') {
    if (!owner || p !== 'config/banner') return fail('permission-denied', 'Баннер меняет только владелец');
    if (op === 'delete') return { ok: true };
    return { ok: true, data: { on: !!data.on, title: norm(data.title, 40), text: norm(data.text, 120), v: Date.now() } };
  }

  if (top === 'clips') {
    if (seg.length !== 2) return deny();
    if (op === 'add') {
      if (!uid) return fail('unauthenticated', 'Войдите в аккаунт');
      if (data.authorId !== uid) return deny();
      const a = state.assets[data.assetId];
      if (!a || a.owner !== uid) return fail('invalid', 'Видео не найдено');
      return { ok: true, data: { authorId: uid, caption: norm(data.caption, 150), assetId: String(data.assetId), t: Number(data.t) || Date.now(), dur: numOrNull(data.dur), w: numOrNull(data.w), h: numOrNull(data.h) } };
    }
    if (!existing) return fail('not-found', 'Ролик не найден');
    if (existing.data.authorId !== uid && !owner) return deny();
    if (op === 'delete') return { ok: true };
    if (op === 'update') return { ok: true, data: { ...existing.data, caption: norm(data.caption, 150) } };
    return deny();
  }

  if (top === 'likes') {
    if (seg.length !== 2) return deny();
    const [cid, lu] = seg[1].split('~');
    if (op === 'delete') return lu === uid || owner ? { ok: true } : deny();
    if (op !== 'set' || !uid || lu !== uid) return deny();
    if (!state.docs['clips/' + cid]) return fail('not-found', 'Ролик не найден');
    return { ok: true, data: { clipId: cid, uid, t: Date.now() } };
  }

  if (top === 'follows') {
    if (seg.length !== 2) return deny();
    const [fu, author] = seg[1].split('~');
    if (op === 'delete') return fu === uid || owner ? { ok: true } : deny();
    if (op !== 'set' || !uid || fu !== uid || author === uid) return deny();
    if (!state.docs['profiles/' + author]) return fail('not-found', 'Пользователь не найден');
    return { ok: true, data: { uid, authorId: author, t: Date.now() } };
  }

  if (top === 'comments') {
    if (seg.length !== 2) return deny();
    if (op === 'delete') return existing && (existing.data.uid === uid || owner) ? { ok: true } : deny();
    if (op !== 'add' || !uid) return sess ? deny() : fail('unauthenticated', 'Войдите в аккаунт');
    const text = norm(data.text, 300);
    if (!text) return fail('invalid', 'Пустой комментарий');
    if (!state.docs['clips/' + data.clipId]) return fail('not-found', 'Ролик не найден');
    return { ok: true, data: { clipId: String(data.clipId), uid, text, t: Date.now() } };
  }

  return deny();
}

function deleteAsset(id) {
  if (!state.assets[id]) return;
  delete state.assets[id];
  try { fs.unlinkSync(assetPath(id)); } catch (e) { /* файла уже нет */ }
}

function applyWrite(w, sess) {
  const op = String(w.op || '');
  let p = String(w.path || '');
  if (!['add', 'set', 'update', 'delete'].includes(op)) return fail('invalid', 'Неизвестная операция');
  if (op === 'add') {
    if (!COLLECTIONS.has(p)) return fail('invalid', 'Неверная коллекция');
    p = p + '/' + rid();
  }
  if (!validPath(p)) return fail('invalid', 'Неверный путь');
  const existing = state.docs[p] || null;
  const r = authorize(op === 'add' ? 'add' : op, p, w.data, sess, existing);
  if (!r.ok) return r;
  if (op === 'delete') {
    delete state.docs[p];
    if (p.startsWith('clips/') && existing) {
      const id = p.slice(6);
      for (const k of Object.keys(state.docs)) {
        if ((k.startsWith('likes/') || k.startsWith('comments/')) && state.docs[k].data.clipId === id) delete state.docs[k];
      }
      deleteAsset(existing.data.assetId);
    }
  } else {
    putDoc(p, r.data);
  }
  return { ok: true, id: p.split('/').pop() };
}

/* ---------- ответы ---------- */
function send(res, status, obj) {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
  res.end(JSON.stringify(obj));
}
async function readJSON(req, limit = 256 * 1024) {
  if (!String(req.headers['content-type'] || '').includes('application/json')) throw Object.assign(new Error('bad type'), { status: 415 });
  const chunks = [];
  let size = 0;
  for await (const c of req) {
    size += c.length;
    if (size > limit) throw Object.assign(new Error('too big'), { status: 413 });
    chunks.push(c);
  }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'); }
  catch (e) { throw Object.assign(new Error('bad json'), { status: 400 }); }
}
const bad = (res, msg, code = 'invalid') => send(res, 400, { error: msg, code });

/* ---------- ассеты (видео) ---------- */
const assetPath = (id) => path.join(DATA_DIR, 'assets', id);
const ID_RE = /^[A-Za-z0-9_-]{8,64}$/;

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.json': 'application/json', '.mp4': 'video/mp4', '.webmanifest': 'application/manifest+json' };

function serveBlob(req, res, id) {
  const a = ID_RE.test(id) ? state.assets[id] : null;
  if (!a) { res.writeHead(404); return res.end(); }
  const file = assetPath(id);
  let size;
  try { size = fs.statSync(file).size; } catch (e) { res.writeHead(404); return res.end(); }
  const headers = { 'content-type': a.type, 'accept-ranges': 'bytes', 'cache-control': 'public, max-age=3600' };
  const range = /bytes=(\d*)-(\d*)/.exec(req.headers.range || '');
  if (range && (range[1] || range[2])) {
    let start, end;
    if (range[1] === '') { const n = Number(range[2]); start = Math.max(0, size - n); end = size - 1; }
    else { start = Number(range[1]); end = range[2] === '' ? size - 1 : Math.min(Number(range[2]), size - 1); }
    if (start > end || start >= size) { res.writeHead(416, { 'content-range': `bytes */${size}` }); return res.end(); }
    res.writeHead(206, { ...headers, 'content-range': `bytes ${start}-${end}/${size}`, 'content-length': end - start + 1 });
    if (req.method === 'HEAD') return res.end();
    return fs.createReadStream(file, { start, end }).pipe(res);
  }
  res.writeHead(200, { ...headers, 'content-length': size });
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(file).pipe(res);
}

async function uploadAsset(req, res, sess) {
  if (!sess) return send(res, 401, { error: 'Войдите в аккаунт', code: 'unauthenticated' });
  const type = String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
  if (!/^(video|image)\/[a-z0-9.+-]+$/.test(type)) return send(res, 415, { error: 'Этот тип файла не поддерживается', code: 'unsupported' });
  if (Number(req.headers['content-length'] || 0) > MAX_UPLOAD) return send(res, 413, { error: 'Файл больше 20 МБ', code: 'quota_exceeded' });
  const chunks = [];
  let size = 0, tooBig = false;
  for await (const c of req) {
    size += c.length;
    if (size > MAX_UPLOAD) { tooBig = true; break; }
    chunks.push(c);
  }
  if (tooBig) return send(res, 413, { error: 'Файл больше 20 МБ', code: 'quota_exceeded' });
  const id = rid();
  fs.writeFileSync(assetPath(id), Buffer.concat(chunks));
  state.assets[id] = { owner: sess.uid, type, size, t: Date.now() };
  changed();
  send(res, 200, { id, url: '/_blob/' + id, sizeBytes: size, contentType: type });
}

/* ---------- первичные данные и перенос со старой версии ---------- */
function ensurePromoAsset() {
  if (!fs.existsSync(assetPath(PROMO_ASSET)) && fs.existsSync(SEED_VIDEO)) fs.copyFileSync(SEED_VIDEO, assetPath(PROMO_ASSET));
  if (fs.existsSync(assetPath(PROMO_ASSET)) && !state.assets[PROMO_ASSET]) {
    state.assets[PROMO_ASSET] = { owner: null, type: 'video/mp4', size: fs.statSync(assetPath(PROMO_ASSET)).size, t: 1791947919455 };
  }
}
function seedForUser(uid, handle) {
  if (handle !== 'andlubown') return;
  if (!state.docs['verified/' + uid]) putDoc('verified/' + uid, { handle, t: 1791922800000 });
  ensurePromoAsset();
  if (state.assets[PROMO_ASSET]) state.assets[PROMO_ASSET].owner = uid;
  if (!state.docs['clips/' + PROMO_ID] && state.assets[PROMO_ASSET]) {
    putDoc('clips/' + PROMO_ID, {
      authorId: uid,
      caption: 'Петля — короткие видео по кругу ∞ Свайпай, лайкай, комментируй. Загрузи свой первый ролик! #петля #видео #первыйролик',
      assetId: PROMO_ASSET, t: 1791947919455, dur: 14, w: 720, h: 1280,
    });
  }
  changed();
}
function seedStartup() {
  if (!state.docs['config/banner']) {
    putDoc('config/banner', { on: true, title: 'Добро пожаловать в Петлю', text: 'Свайпайте вверх, двойной тап ставит лайк. Новости будут появляться здесь.', v: 1791922993253 });
  }
  // если владелец уже зарегистрирован, докладываем его галочку и ролик
  for (const [key, d] of Object.entries(state.docs)) {
    if (key.startsWith('profiles/') && d.data && d.data.handle === 'andlubown') seedForUser(key.slice(9), 'andlubown');
  }
  changed();
}

/* ---------- маршруты ---------- */
async function route(req, res) {
  const url = new URL(req.url, 'http://localhost');
  const p = url.pathname;
  const m = req.method;

  if (p.startsWith('/_blob/')) {
    if (m !== 'GET' && m !== 'HEAD') return send(res, 405, { error: 'Метод не поддерживается' });
    return serveBlob(req, res, p.slice(7));
  }

  if (p.startsWith('/api/')) {
    const sess = sessionOf(req);

    if (p === '/api/me' && m === 'GET') {
      if (!sess) return send(res, 200, { uid: null, isOwner: false, hasEmail: false });
      const prof = state.docs['profiles/' + sess.uid];
      return send(res, 200, { uid: sess.uid, email: sess.email, isOwner: sess.isOwner, hasEmail: true, handle: prof ? prof.data.handle : '' });
    }

    if (p === '/api/events' && m === 'GET') {
      res.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-cache', connection: 'keep-alive' });
      res.write(': ok\n\n');
      sseClients.add(res);
      const ping = setInterval(() => res.write(': ping\n\n'), 25000);
      req.on('close', () => { clearInterval(ping); sseClients.delete(res); });
      return;
    }

    if (p === '/api/db' && m === 'GET') {
      const path_ = url.searchParams.get('path') || '';
      const seg = path_.split('/');
      if (!COLLECTIONS.has(seg[0]) || !seg.every((s) => SAFE_SEG.test(s))) return send(res, 400, { error: 'Неверный путь', code: 'invalid' });
      if (seg.length % 2 === 0) {
        const d = state.docs[path_];
        return send(res, 200, d ? { exists: true, data: d.data, version: d.version } : { exists: false });
      }
      const prefix = path_ + '/';
      const docs = [];
      for (const [k, v] of Object.entries(state.docs)) {
        if (k.startsWith(prefix) && !k.slice(prefix.length).includes('/')) docs.push({ id: k.slice(prefix.length), data: v.data, version: v.version });
      }
      return send(res, 200, { docs });
    }

    if (p === '/api/db/write' && m === 'POST') {
      const body = await readJSON(req);
      const writes = Array.isArray(body.writes) ? body.writes.slice(0, 50) : [];
      const results = [];
      for (const w of writes) {
        const r = applyWrite(w, sess);
        if (!r.ok) return send(res, r.code === 'permission-denied' ? 403 : r.code === 'not-found' ? 404 : r.code === 'unauthenticated' ? 401 : 400, { error: r.msg, code: r.code, ids: results });
        results.push(r.id);
      }
      changed();
      return send(res, 200, { ok: true, ids: results });
    }

    if (p === '/api/handle' && m === 'GET') {
      const h = norm(url.searchParams.get('name'), 20).toLowerCase();
      if (!HANDLE_RE.test(h)) return send(res, 200, { free: false, valid: false });
      return send(res, 200, { free: !state.handles[h] || state.handles[h] === sess?.uid, valid: true });
    }

    if (p === '/api/assets' && m === 'POST') return uploadAsset(req, res, sess);

    if (p.startsWith('/api/assets/') && m === 'DELETE') {
      if (!sess) return send(res, 401, { error: 'Войдите в аккаунт', code: 'unauthenticated' });
      const id = p.slice('/api/assets/'.length);
      const a = state.assets[id];
      if (!a) return send(res, 404, { error: 'Файл не найден', code: 'not-found' });
      if (a.owner !== sess.uid && !sess.isOwner) return send(res, 403, { error: 'Нет прав', code: 'permission-denied' });
      deleteAsset(id);
      changed();
      return send(res, 200, { ok: true });
    }

    if (p.startsWith('/api/auth/') && m === 'POST') {
      if (p === '/api/auth/logout') {
        if (sess) delete state.sessions[sess.token];
        changed();
        res.setHeader('Set-Cookie', `petlya_sid=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${cookieFlags(req)}`);
        return send(res, 200, { ok: true });
      }

      if (p === '/api/auth/register') {
        if (tooMany(req)) return send(res, 429, { error: 'Слишком много попыток. Подождите немного.', code: 'rate-limited' });
        const b = await readJSON(req);
        const email = cleanEmail(b.email);
        if (!email) return bad(res, 'Введите настоящую почту, например name@example.com');
        const password = String(b.password || '');
        if (password.length < 8 || password.length > 200) return bad(res, 'Пароль должен быть не короче 8 символов');
        const handle = norm(b.handle, 20).toLowerCase();
        if (!HANDLE_RE.test(handle)) return bad(res, 'Имя пользователя: от 3 до 20 символов, латиница, цифры и «_»');
        const name = norm(b.name, 30);
        if (!name) return bad(res, 'Введите отображаемое имя');
        const bio = norm(b.bio, 80);
        const color = HEX_RE.test(b.color || '') ? b.color : '#7bd88f';
        if (state.emails[email]) return send(res, 409, { error: 'Эта почта уже зарегистрирована', code: 'conflict' });
        if (state.handles[handle]) return send(res, 409, { error: 'Это имя пользователя уже занято', code: 'conflict' });
        const uid = 'u_' + rid();
        const salt = crypto.randomBytes(16).toString('hex');
        state.users[uid] = { email, salt, hash: hashPassword(password, salt), t: Date.now() };
        state.emails[email] = uid;
        state.handles[handle] = uid;
        putDoc('profiles/' + uid, { handle, name, bio, color, hasEmail: true, t: Date.now() });
        seedForUser(uid, handle);
        startSession(req, res, uid);
        return send(res, 200, { ok: true, uid });
      }

      if (p === '/api/auth/login') {
        if (tooMany(req)) return send(res, 429, { error: 'Слишком много попыток. Подождите немного.', code: 'rate-limited' });
        const b = await readJSON(req);
        const email = cleanEmail(b.email);
        const password = String(b.password || '');
        const uid = email ? state.emails[email] : null;
        const u = uid ? state.users[uid] : null;
        const ok = u ? checkPassword(password, u.salt, u.hash) : (checkPassword(password, DUMMY_SALT, DUMMY_HASH), false);
        if (!ok) return send(res, 401, { error: 'Неверная почта или пароль', code: 'bad-credentials' });
        startSession(req, res, uid);
        return send(res, 200, { ok: true, uid });
      }

      if (p === '/api/auth/credentials') {
        if (!sess) return send(res, 401, { error: 'Войдите в аккаунт', code: 'unauthenticated' });
        const b = await readJSON(req);
        const u = state.users[sess.uid];
        const email = b.email ? cleanEmail(b.email) : null;
        const pw = b.password ? String(b.password) : null;
        if (b.email && !email) return bad(res, 'Введите настоящую почту');
        if (pw !== null && (pw.length < 8 || pw.length > 200)) return bad(res, 'Пароль должен быть не короче 8 символов');
        if (email) {
          if (u.email) return bad(res, 'Почта уже привязана');
          if (state.emails[email]) return send(res, 409, { error: 'Эта почта уже зарегистрирована', code: 'conflict' });
          u.email = email;
          state.emails[email] = sess.uid;
        }
        if (pw) { u.salt = crypto.randomBytes(16).toString('hex'); u.hash = hashPassword(pw, u.salt); }
        if (!u.email) return bad(res, 'Укажите почту и пароль');
        const prof = state.docs['profiles/' + sess.uid];
        if (prof) putDoc('profiles/' + sess.uid, { ...prof.data, hasEmail: true });
        changed();
        return send(res, 200, { ok: true });
      }
    }

    return send(res, 404, { error: 'Не найдено', code: 'not-found' });
  }

  if (m !== 'GET' && m !== 'HEAD') return send(res, 405, { error: 'Метод не поддерживается' });
  let rel = p === '/' ? '/index.html' : p;
  let file;
  try { file = path.normalize(path.join(PUBLIC_DIR, decodeURIComponent(rel))); } catch (e) { res.writeHead(400); return res.end(); }
  if (!file.startsWith(PUBLIC_DIR + path.sep) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
    return res.end('Не найдено');
  }
  res.writeHead(200, { 'content-type': MIME[path.extname(file)] || 'application/octet-stream', 'cache-control': 'no-cache', 'x-content-type-options': 'nosniff', 'referrer-policy': 'same-origin' });
  if (m === 'HEAD') return res.end();
  fs.createReadStream(file).pipe(res);
}

seedStartup();

http.createServer((req, res) => {
  route(req, res).catch((e) => {
    if (e && e.status) { if (!res.headersSent) send(res, e.status, { error: e.message, code: 'bad-request' }); return; }
    console.error(e);
    if (!res.headersSent) send(res, 500, { error: 'Внутренняя ошибка сервера', code: 'internal' });
  });
}).listen(PORT, () => console.log(`Петля запущена на порту ${PORT}, данные: ${DATA_DIR}`));
